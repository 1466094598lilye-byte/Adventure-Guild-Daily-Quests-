import { base44 } from './base44Client';


export const Quest = base44.entities.Quest;

export const Loot = base44.entities.Loot;

export const DailyChest = base44.entities.DailyChest;

export const LongTermProject = base44.entities.LongTermProject;



// auth sdk:
export const User = base44.auth;